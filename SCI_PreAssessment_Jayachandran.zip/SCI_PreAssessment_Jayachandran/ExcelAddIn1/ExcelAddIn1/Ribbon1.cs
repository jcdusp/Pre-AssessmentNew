﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Office.Tools.Ribbon;
using Excel = Microsoft.Office.Interop.Excel;


namespace ExcelAddIn1
{

    public partial class Ribbon1
    {
        private Dictionary<string, object> originalValues = new Dictionary<string, object>();

        public object Application { get; private set; }

        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {

        }

        private void button1_Click(object sender, RibbonControlEventArgs e)
        {
            try
            {
                Excel.Range selection = Globals.ThisAddIn.Application.Selection as Excel.Range;
                if (selection == null)
                {
                    MessageBox.Show("Please select one or more cells first.", "No Selection");
                    return;
                }

                Regex regex = new Regex("[^a-zA-Z0-9]+");

                foreach (Excel.Range cell in selection.Cells)
                {
                    if (cell != null && cell.Value2 != null)
                    {
                        string cellAddress = cell.Address[false, false, Excel.XlReferenceStyle.xlA1];
                        // Store the original value if not already stored
                        if (!originalValues.ContainsKey(cellAddress))
                        {
                            originalValues[cellAddress] = cell.Value2;
                        }

                        string original = cell.Value2.ToString();
                        string sanitized = regex.Replace(original, string.Empty);
                        cell.Value2 = sanitized;
                    }
                }
               
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Exception");
            }
        }

        private void button2_Click(object sender, RibbonControlEventArgs e)
        {
            if (originalValues.Count == 0)
            {
                System.Windows.Forms.MessageBox.Show("No original values stored to revert.");
                return;
            }
            
            Excel.Worksheet activeSheet = Globals.ThisAddIn.Application.ActiveSheet as Excel.Worksheet;
            if (activeSheet == null) return;

            foreach (var kvp in originalValues)
            {
                try
                {
                    Excel.Range cell = activeSheet.Range[kvp.Key];
                    cell.Value2 = kvp.Value;
                }
                catch (Exception ex)
                {
                    // Handle any unexpected errors such as invalid range references
                    System.Diagnostics.Debug.WriteLine($"Failed to revert cell {kvp.Key}: {ex.Message}");
                }
            }

            originalValues.Clear();
        }
    }
}
