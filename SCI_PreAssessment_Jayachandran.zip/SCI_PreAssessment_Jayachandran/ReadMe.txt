
Task status
---------
Exercise 1: Excel Add-in (VSTO / Office Add-in) - completed
Exercise 2: RESTful API with Enhanced CRUD -- Completed

Exercise 3: FindChips Distributor Data Aggregation Tool -- not able to complete
Note: using Asyn method i try to expert excel i worked only json or xml file. your put url not able to export the data.