﻿using ASPNETCoreApplication.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Text.Json;
using System.Text.Json.Serialization;
//using Newtonsoft.Json;



namespace ASPNETCoreApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        public readonly IConfiguration _configuration;
        public EmployeeController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetAllEmployee")]
        public string  GetEmployee()
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection").ToString());
            SqlDataAdapter da=new SqlDataAdapter("select Empid, FirstName, LastName, Age, Salary from Employee", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Response Res=new Response();
            List<Employeevalue> emplistval = new List<Employeevalue>();
            if (dt.Rows.Count>0)
            {
                for (int i = 0; i < dt.Rows.Count; i++) {

                    Employeevalue empval = new Employeevalue();
                    empval.Empid = Convert.ToInt32(dt.Rows[i]["Empid"]);
                    empval.FirstName = Convert.ToString(dt.Rows[i]["FirstName"]);
                    empval.LastName = Convert.ToString(dt.Rows[i]["LastName"]);
                    empval.Age = Convert.ToInt32(dt.Rows[i]["Age"]);
                    empval.Salary = Convert.ToInt32(dt.Rows[i]["Salary"]);
                    emplistval.Add(empval);

                }

            }
            if (emplistval.Count > 0)
            {
               // DataTable dta = new DataTable();
                //dta = JsonSerializer.Deserialize(emplistval);
                return JsonSerializer.Serialize(emplistval);
            }
            else
            {
                Res.StatusCode = 100;
                Res.Errors = "No Error Found.";
                return JsonSerializer.Serialize(Res);
            }
        }

    }
}
