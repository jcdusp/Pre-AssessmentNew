﻿
namespace ASPNETCoreApplication.Models
{
    public class Employeevalue
    {
        public int Empid { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public int Salary { get; set; }
    }
}
