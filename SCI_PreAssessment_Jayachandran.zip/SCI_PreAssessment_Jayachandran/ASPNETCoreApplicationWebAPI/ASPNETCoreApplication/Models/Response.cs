﻿namespace ASPNETCoreApplication.Models
{
    public class Response
    {
        public int StatusCode { get; set; }
        public string Errors { get; set; }
    }
}
