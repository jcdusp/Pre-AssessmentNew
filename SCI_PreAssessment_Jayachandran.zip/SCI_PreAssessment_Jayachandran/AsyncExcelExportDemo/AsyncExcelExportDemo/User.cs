﻿namespace AsyncExcelExportDemo
{
    public class User
    {
        public string Manufacturer { get; set; }
        public int Stock { get; set; }
        public decimal Price { get; set; }

        public string Currency { get; set; }
    }
}
