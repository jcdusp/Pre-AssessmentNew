﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using ClosedXML.Excel;

namespace AsyncExcelExportDemo
{
    // Example data model for deserialized API response
    public class Post
    {
        public int UserId { get; set; }
        public int Id { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
    }

    class ProgramAsy
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Fetching data asynchronously from JSONPlaceholder API...");

            List<Post> posts = await FetchPostsAsync();

            Console.WriteLine($"Fetched {posts.Count} posts.");

            string filePath = "ExportedPosts.xlsx";

            ExportPostsToExcel(posts, filePath);

            Console.WriteLine($"Data exported successfully to {filePath}");
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        // Asynchronously fetch data from external platform (REST API)
        private static async Task<List<Post>> FetchPostsAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://jsonplaceholder.typicode.com/");
                HttpResponseMessage response = await client.GetAsync("posts");
                response.EnsureSuccessStatusCode();

                string json = await response.Content.ReadAsStringAsync();

                // Deserialize JSON to list of Post objects
                List<Post> posts = JsonConvert.DeserializeObject<List<Post>>(json);

                return posts;
            }
        }

        // Export structured data into Excel file using ClosedXML
        private static void ExportPostsToExcel(List<Post> posts, string filePath)
        {
            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Posts");

                // Add headers
                worksheet.Cell(1, 1).Value = "UserId";
                worksheet.Cell(1, 2).Value = "Id";
                worksheet.Cell(1, 3).Value = "Title";
                worksheet.Cell(1, 4).Value = "Body";

                // Insert data starting at row 2
                int row = 2;
                foreach (var post in posts)
                {
                    worksheet.Cell(row, 1).Value = post.UserId;
                    worksheet.Cell(row, 2).Value = post.Id;
                    worksheet.Cell(row, 3).Value = post.Title;
                    worksheet.Cell(row, 4).Value = post.Body;
                    row++;
                }

                // Adjust column widths
                worksheet.Columns().AdjustToContents();

                workbook.SaveAs(filePath);
            }
        }
    }
}
