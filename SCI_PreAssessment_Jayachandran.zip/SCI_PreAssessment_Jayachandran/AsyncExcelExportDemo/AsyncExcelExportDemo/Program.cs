using AsyncExcelExportDemo;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using Newtonsoft.Json;
using System.Threading.Tasks;
using HtmlAgilityPack;
using DocumentFormat.OpenXml.VariantTypes;



var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => "Hello World!");

Console.WriteLine("Fetching website HTML data asynchronously...");

var data = await ScrapeCountryPopulationTableAsync();

Console.WriteLine($"Scraped {data.Count} rows.");

string filePath = "WebsiteScrapedData.xlsx";

ExportToExcel(data, filePath);

Console.WriteLine($"Data exported successfully to {filePath}");
Console.WriteLine("Press any key to exit.");
Console.ReadKey();

// Async fetch and parse HTML table data from a website
static async Task<List<User>> ScrapeCountryPopulationTableAsync()
{
    string url = "https://www.findchips.com/search/2N222";

    using (HttpClient client = new HttpClient())
    {
        string html = await client.GetStringAsync(url);

        var htmlDoc = new HtmlDocument();
        htmlDoc.LoadHtml(html);

        var data = new List<User>();

        // The main table has id "example2"
        var table = htmlDoc.DocumentNode.SelectSingleNode("//table[@id='example2']");

        if (table == null)
            return data;

        // Select all rows except header
        var rows = table.SelectNodes(".//tbody/tr");

        if (rows == null)
            return data;

        foreach (var row in rows)
        {
            var cells = row.SelectNodes("td");
            if (cells == null || cells.Count < 5)
                continue;

            // Example columns:
            // 1: Manufacturer name
            // 2: Stock 
            // 3: Price
            //Currency

            var rowData = new User
            {
                Manufacturer = cells[1].InnerText.Trim(),
                Stock = Convert.ToInt16(cells[2].InnerText.Trim()),
                Price = Convert.ToInt16(cells[3].InnerText.Trim()),
                Currency = "INR"
            };

            data.Add(rowData);
        }

        return data;
    }
}

// Export scraped data to Excel using ClosedXML
static void ExportToExcel(List<User> data, string filePath)
{
    using (var workbook = new XLWorkbook())
    {
        var worksheet = workbook.Worksheets.Add("PopulationData");

        worksheet.Cell(1, 1).Value = "Manufacturer";
        worksheet.Cell(1, 2).Value = "Stock";
        worksheet.Cell(1, 3).Value = "Price";
        worksheet.Cell(1, 4).Value = "Currency";

        int row = 2;
        foreach (var item in data)
        {
            worksheet.Cell(row, 1).Value = item.Manufacturer;
            worksheet.Cell(row, 2).Value = item.Stock;
            worksheet.Cell(row, 3).Value = item.Price;
            worksheet.Cell(row, 3).Value = item.Currency;
            row++;
        }

        worksheet.Columns().AdjustToContents();

        workbook.SaveAs(filePath);
    }
}

app.Run();
